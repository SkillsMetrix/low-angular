import { CanActivate } from "@angular/router";



export class PreventRoute implements CanActivate {

    isAllowed = false
    canActivate() {
        if (!this.isAllowed) {
            alert('not allowed to acess')
        } else {

            //this.isAllowed = true;
        }
        return this.isAllowed
    }


}