import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { PreventRoute } from '../../../shared/preventRoute';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  constructor(private route:Router,private pr:PreventRoute)
{

}
  login(nf:NgForm){
    this.pr.isAllowed=true
    this.route.navigateByUrl('/portfolio')
    

  }
}
