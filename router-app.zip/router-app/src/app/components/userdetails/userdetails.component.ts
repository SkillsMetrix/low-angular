import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrl: './userdetails.component.css'
})
export class UserdetailsComponent {

myid:string=''
action:string=''
  constructor(ac:ActivatedRoute){
    this.myid=ac.snapshot.params['id']
    this.action=ac.snapshot.params['action']
  }



}
