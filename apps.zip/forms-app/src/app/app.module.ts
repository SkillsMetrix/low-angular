import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './components/form/form.component';
import { FormService } from '../shared/formservice.service';
import  { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatadrivenComponent } from './components/datadriven/datadriven.component'
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http'
import { Logger } from '../shared/Logger.interceptor';
import { Logger2 } from '../shared/Logger2.interceptor';
@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    DatadrivenComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule



  ],
  providers: [FormService,
    {provide: HTTP_INTERCEPTORS,useClass:Logger,multi:true},
    {provide: HTTP_INTERCEPTORS,useClass:Logger2,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
