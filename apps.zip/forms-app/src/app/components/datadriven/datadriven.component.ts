import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../../../shared/formservice.service';

@Component({
  selector: 'app-datadriven',
  templateUrl: './datadriven.component.html',
  styleUrl: './datadriven.component.css'
})
export class DatadrivenComponent {
  myForm:FormGroup
  uname:FormControl
  password: FormControl
  email:FormControl
  city:FormControl

  createFormControl(){
    this.uname= new FormControl('',Validators.required)
    this.password= new FormControl('',[Validators.required,Validators.minLength(6)])
    this.email= new FormControl('',[Validators.required,Validators.email,this.emailDomainValidator])
    this.city= new FormControl('')
  }
  createForm(){
    this.myForm= new FormGroup({
      uname:this.uname,
      password:this.password,
      email:this.email,
      city:this.city
    })
  }
  users:any[]=[]
  loadUsers(){
    this.fs.loadDatafromDB().subscribe((res)=>{
      const myArray=[]
      for(let key in res){
        myArray.push(res[key])
      }
      this.users=myArray
    })
  }
constructor(private fs:FormService){
  this.createFormControl()
  this.createForm()
  //
  
}
addUser(){
   this.fs.addUserToDB(this.myForm.value)
  
}
emailDomainValidator(control:FormControl){
  let email= control.value
  if(email && email.indexOf('@') != -1){
    let[before,domain]= email.split('@')
    if(domain !=='lnw.com'){
      return {
        emailDomain:{
          parseDomain: domain
        }
      }
    }
  }
  return null
}
}
