import { Component } from '@angular/core';
import { FormService } from '../../../shared/formservice.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrl: './form.component.css'
})
export class FormComponent {
constructor(private fs:FormService){}
  addUser(nf:NgForm){
     
    this.fs.addUserToDB(nf.value)
    
  }
}
