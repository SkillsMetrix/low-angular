import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class FormService{

    HTTP_URL='https://lnw-angular2-default-rtdb.firebaseio.com/users.json'
    constructor(private http:HttpClient){}
    addUserToDB(data:any){
       this.http.post(this.HTTP_URL,data)
       .subscribe(data=>{
        console.log(data);
        
       })
        
    }

    loadDatafromDB(){
        return this.http.get(this.HTTP_URL)
    }
}