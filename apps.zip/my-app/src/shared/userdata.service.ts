import { Injectable } from "@angular/core";

@Injectable()
export class UserService {

    loadUsers(): string[] {

        return ['admin', 'manager', 'QA']
    }

    loadPeople(): any[] {

        return [

            {
                name: "duglus",
                country: 'Australia'
            },
            {
                name: "smith",
                country: 'USA'
            },
            {
                name: "sonal",
                country: 'India'
            },



        ]
    }
}