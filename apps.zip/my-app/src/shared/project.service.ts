import { Injectable } from "@angular/core";

@Injectable()
export class ProjectService {

    projectUsers():string[]{

        return ['HRMS','finance','apps']
    }
}