import { Component } from '@angular/core';
import { UserService } from '../../../shared/userdata.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  uname = 'santosh'
  pp = 'https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg'
  people: any[] = []
  constructor(private lp: UserService) {
    this.people = this.lp.loadPeople()
  }
  addUser() {
    alert('user added')
  }

  getColor(country: string) {
    switch (country) {

      case 'Australia':
        return 'blue'

      case 'India':
        return 'green'

      case 'USA':
        return 'purple'
      default:
        return null
    }
  }

}
