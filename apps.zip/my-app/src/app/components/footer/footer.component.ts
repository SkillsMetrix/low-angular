import { Component } from '@angular/core';
import { UserService } from '../../../shared/userdata.service';
import { ProjectService } from '../../../shared/project.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {

  constructor(private us:UserService,private ps:ProjectService){
    this.userData=this.us.loadUsers()
    this.userProjects=ps.projectUsers()
  }

  userData:any

  userProjects:any

}
