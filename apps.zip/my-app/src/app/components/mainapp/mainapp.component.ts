import { Component, ViewChild } from '@angular/core';
import { UsersComponent } from '../users/users.component';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {

  shopCart=['perfume']

  newname='smith'
 
  @ViewChild(UsersComponent)
  private users={} as UsersComponent

  inc(){
    this.users.increment()
  }
  dec(){
    this.users.decrement()
  }

}
