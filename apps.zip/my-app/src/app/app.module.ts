import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { UserService } from '../shared/userdata.service';
import { ProjectService } from '../shared/project.service';
import { FormsModule } from '@angular/forms';
import { AdduserComponent } from './components/adduser/adduser.component';
import { UserComponent } from './components/user/user.component';
import { UsersComponent } from './components/users/users.component'

@NgModule({
  // it contains all the components,pipes and directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    AdduserComponent,
    UserComponent,
    UsersComponent
  ],
  // contains all the module
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  // contains all the services
  providers: [UserService,ProjectService],
  // contains first file to load when app starts
  bootstrap: [AppComponent]
})
export class AppModule { }
